export enum DEFAULTS {
    sound1  =  "media/AAA_Powerline.mp3"
}