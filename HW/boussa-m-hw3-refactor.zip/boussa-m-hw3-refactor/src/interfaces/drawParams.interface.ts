export interface DrawParams{
    visMethod: number,
    drawMethod: string
}
