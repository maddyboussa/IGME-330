const doubleIt = num => num * 2;

export {doubleIt};